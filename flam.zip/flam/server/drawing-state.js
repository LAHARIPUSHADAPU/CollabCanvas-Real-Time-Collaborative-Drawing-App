import fs from "fs";
import path from "path";

export function createDrawingState(roomId = "main", dataDir = "data") {
  const file = path.join(dataDir, `${sanitize(roomId)}.json`);
  const history = load(file);
  const undone = [];

  function save() {
    try { fs.writeFileSync(file, JSON.stringify(history, null, 2)); }
    catch (e) { console.error("Persist error:", e); }
  }

  return {
    addOperation(op) { if (!op) return; history.push(op); undone.length = 0; save(); },
    undo(opId) {
      const idx = history.findIndex((o) => o.id === opId);
      if (idx >= 0) { const [op] = history.splice(idx, 1); undone.push(op); save(); }
    },
    redo(opId) {
      const idx = undone.findIndex((o) => o.id === opId);
      if (idx >= 0) { const [op] = undone.splice(idx, 1); history.push(op); save(); }
    },
    clear() { history.length = 0; undone.length = 0; save(); },
    getAll() { return history; },
  };
}

function load(file) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (e) { console.error("Load error:", e); }
  return [];
}
function sanitize(s){ return String(s).replace(/[^a-z0-9_-]/ig,'_'); }
