import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import { createRoomManager } from "./rooms.js";
import fs from "fs";
import path from "path";

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

// Ensure data dir for persistence
const DATA_DIR = path.resolve("data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const rooms = createRoomManager(DATA_DIR);

// Serve static frontend
app.use(express.static("client"));

// Upgrade only for /ws
server.on("upgrade", (req, socket, head) => {
  if (req.url === "/ws") {
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", (ws) => {
  let room = null;
  const userId = Math.random().toString(36).substring(2, 10);

  ws.on("message", (msg) => {
    try {
      const data = JSON.parse(msg);
      const { type, payload } = data;

      // Join a room
      if (type === "join") {
        const roomId = payload?.roomId || "main";
        room = rooms.joinRoom(roomId, ws, userId);
        // Send persisted ops to new client
        ws.send(JSON.stringify({ type: "init", payload: room.state.getAll() }));
        return;
      }

      // Latency check
      if (type === "ping") {
        ws.send(JSON.stringify({ type: "evt", payload: { type: "pong", payload } }));
        return;
      }

      // Broadcast any event as { type:'evt', payload:{ type, payload } }
      if (room) room.broadcast(ws, { type: "evt", payload: { type, payload } });
    } catch (err) {
      console.error("Bad WS message:", err);
    }
  });

  ws.on("close", () => {
    if (room) rooms.leaveRoom(room.id, ws, userId);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 http://localhost:${PORT}`);
  console.log(`🌐 ws://localhost:${PORT}/ws`);
});
