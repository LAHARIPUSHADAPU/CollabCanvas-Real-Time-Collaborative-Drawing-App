import { createDrawingState } from "./drawing-state.js";

export function createRoomManager(dataDir) {
  const rooms = new Map();

  function getRoom(id) {
    if (!rooms.has(id)) rooms.set(id, createRoom(id));
    return rooms.get(id);
  }

  function createRoom(id) {
    const state = createDrawingState(id, dataDir);
    const clients = new Set();

    function broadcast(sender, msg) {
      // send to peers
      clients.forEach((ws) => {
        if (ws !== sender && ws.readyState === ws.OPEN) {
          ws.send(JSON.stringify(msg));
        }
      });

      // persist operations
      const t = msg?.payload?.type;
      const p = msg?.payload?.payload;
      if (t === "op:commit") state.addOperation(p);
      if (t === "op:undo") state.undo(p?.opId);
      if (t === "op:redo") state.redo(p?.opId);
      if (t === "op:clear") state.clear();
    }

    return {
      id,
      clients,
      state,
      broadcast,
      join(ws) {
        clients.add(ws);
      },
      leave(ws) {
        clients.delete(ws);
      },
    };
  }

  function joinRoom(id, ws) {
    const room = getRoom(id);
    room.join(ws);
    return room;
  }

  function leaveRoom(id, ws) {
    const room = rooms.get(id);
    if (room) room.leave(ws);
  }

  return { joinRoom, leaveRoom };
}
